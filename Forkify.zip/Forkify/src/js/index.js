// Global app controller
import num from './test';

console.log(`i imported ${num} from another module`);