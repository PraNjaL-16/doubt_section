console.log('Imported module');
export default 23;