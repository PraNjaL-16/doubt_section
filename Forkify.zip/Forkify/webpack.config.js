const path = require('path');

module.export = {
    entry: './src/js/index.js',
    output: {
        path: path.resolve(_dirname,'dist/js'),
        fileName: 'bundle.js'
    }
    mode: 'development'
};